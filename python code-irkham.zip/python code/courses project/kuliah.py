#NIM : 3311401009
#penggunaan fungsi writelines

def tulisberkas():
	berkas = open('kuliah.txt','w')
	print ("Masukkan 5 mata kuliah Teknik Informatika :")
	for j in range (5):
		kuliah=raw_input("Mata Kuliah ke-"+str(j+1)+" : ")
		berkas.writelines(kuliah+"\n")
	berkas.close()
	print ("Proses Penulisan selesai...!!")
	print ("silahkan periksa berkas ",berkas.name)
	
#pemanggilan fungsi tulis berkas
tulisberkas()