#NIM : 3311401022
#NAMA : Ela Erminawati

def tambah():
        nfile = raw_input("Masukkan Nama File yang akan ditambahkan : ")
        file = open(nfile,"a")
        print "Tambahkan 3 data pada file :",file.name
        for j in range (3):
                data =raw_input("Data Ke - "+str(j+1)+" : ")
                file.write("\n"+data)
                        
                
        file.close()
        print "Proses Penulisan Selesai...........!!"
        print "Silahkan periksa file",file.name


tambah()
