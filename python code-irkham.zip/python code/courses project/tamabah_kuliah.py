#NIm : 3311401009
#Menambah data pada file

def tambahFile():
	file = open ('kuliah.txt','a')
	print ("Tambahkan 3 mata kuliah pada file",file.name)
	for j in range(3):
		kuliah =raw_input("Mata kuliah ke-"+str(j+1)+" : ")
		file.write(kuliah+"\n")
	file.close()
	print ("proses Penulisan selesai...!")
	print("Silahkan periksa file",file.name)
#pemanggilan fungsi tambah file
tambahFile()