#3311401066
#menulis ke dalam file

def tulisFile():
	file = open("kota.txt",'w')
	print "10 Nama Kota di Indonesia"
	print "_________________________"
	print "Silahkan masukkan 10 nama Kota yang anda ketahui."
	dataKota=[]
	for i in range (10):
		print "Kota ke-",(i+1),
		kota=raw_input(": ")
		file.write(kota+"\n")
		dataKota.insert(i,kota)
	file.close()
	print "______________________________"
	print "10 Kota yang di masukkan adalah"
	for i in range (10):
		print(i+1), ".",dataKota[i]
	print "Proses Selesai . . . .!!"
	print "Silahkan lihat file",file.name

#	memanggil fungsi tulis file
tulisFile()