#NIM : 3311401009 Copyright
#Menulis Ke dalam Berkas

def tulisberkas():
	berkas = open ("negara.txt",'w')
	print " 10 Nama Negara "
	print "___________________"
	print "Silahkan masukkan 10 nama negara"
	dataNegara = []
	for i in range (10):
		print " Negara ke-", (i+1),
		Negara=raw_input(" : ")
		berkas.write(Negara+"\n")
		dataNegara.insert(i,Negara)
		
	berkas.close()
	print "________________________________________"
	print "10 nama negara yang dimasukkan adalah:"
	for i in range (10):
		print (i+1),".",dataNegara[i]
	print " proses Selesai....!"
	print "Silahkan lihat berkas",berkas.name
	
#pemanggilan fungsi tulis berkas
tulisberkas()